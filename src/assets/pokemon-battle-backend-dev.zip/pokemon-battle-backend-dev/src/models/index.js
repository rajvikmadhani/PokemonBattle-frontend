import sequelize from "../config/database.js";
import Leaderboard from "./Leaderboard.js";
import User from "./User.js";

const db = {
    sequelize,
    Leaderboard,
    User,
};

User.hasOne(Leaderboard, { foreignKey: "username", sourceKey: "username" });
Leaderboard.belongsTo(User, { foreignKey: "username", targetKey: "username" });

Object.entries(db).forEach(([name, model]) => {
    if (model && typeof model.associate === "function") {
        model.associate(db);
    }
});

export default db;
