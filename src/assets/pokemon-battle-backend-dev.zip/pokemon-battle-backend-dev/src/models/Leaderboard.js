import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";

const Leaderboard = sequelize.define(
    "Leaderboard",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        username: {
            type: DataTypes.STRING,
            allowNull: false,
            references: {
                model: "Users",
                key: "username",
            },
        },
        score: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        roster: {
            type: DataTypes.ARRAY(DataTypes.INTEGER),
            allowNull: false,
        },
    },
    {
        timestamps: true,
    }
);

export default Leaderboard;
