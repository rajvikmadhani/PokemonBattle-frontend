import express from "express";
import cors from "cors";

import leaderboardRoutes from "./routes/leaderboardRoutes.js";
import userRouter from "./routes/userRouter.js";
import authRouter from "./routes/authRouter.js";

const app = express();
const port = 3000;

console.log(`CORS allow now ${process.env.FRONTEND_URL}`);

app.use(
    cors({
        origin: process.env.FRONTEND_URL,
        credentials: true,
    })
);

// Middleware to parse JSON
app.use(express.json());

// Use the leaderboard routes
app.use("/leaderboard", leaderboardRoutes);
app.use("/users", userRouter);
app.use("/auth", authRouter);

// Start the server
app.listen(port, () => {
    console.log(`✅ Server running on http://localhost:${port}`);
});
