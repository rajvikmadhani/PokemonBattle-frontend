import express from "express";
import { loginUser, getMe } from "../controllers/authController.js";

const authRouter = express.Router();

authRouter.post("/login", loginUser);
authRouter.get("/me", getMe);

export default authRouter;
