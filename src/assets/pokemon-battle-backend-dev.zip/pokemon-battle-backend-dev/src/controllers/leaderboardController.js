import Leaderboard from "../models/Leaderboard.js";

export const getLeaderboard = async (req, res) => {
  try {
    const scores = await Leaderboard.findAll({ order: [["score", "DESC"]] });
    res.json(scores);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const addScore = async (req, res) => {
  try {
    const { username, score } = req.body;
    if (!username || typeof score !== "number") {
      return res.status(400).json({ error: "Invalid input" });
    }

    const newScore = await Leaderboard.create({ username, score });
    res.status(201).json(newScore);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
